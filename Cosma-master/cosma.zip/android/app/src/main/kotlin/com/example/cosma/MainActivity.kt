package com.example.cosma

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
